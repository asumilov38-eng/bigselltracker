import asyncio, logging, os
from datetime import datetime, timedelta, timezone
from dotenv import load_dotenv
from aiogram import Bot, Dispatcher
from aiogram.filters import CommandStart, Command
from aiogram.types import Message, ReplyKeyboardMarkup, KeyboardButton, WebAppInfo
from aiogram.utils.keyboard import ReplyKeyboardBuilder
from aiohttp import web, ClientSession
from database import init_db, due_reminders, mark_reminder_sent
from api import make_app

load_dotenv()
BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
WEBAPP_URL = os.getenv("WEBAPP_URL", "").strip()
OWNER_USERNAME = os.getenv("OWNER_USERNAME", "ERE321").lstrip("@").lower()
OWNER_ID = int(os.getenv("OWNER_ID", "0") or 0)
PORT = int(os.getenv("PORT", "8080"))

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")
log = logging.getLogger("sale_tracker")
dp = Dispatcher()

def app_keyboard():
    kb = ReplyKeyboardBuilder()
    if WEBAPP_URL:
        kb.add(KeyboardButton(text="Открыть SALE TRACKER", web_app=WebAppInfo(url=WEBAPP_URL)))
    kb.add(KeyboardButton(text="Мой Telegram"))
    kb.adjust(1)
    return kb.as_markup(resize_keyboard=True)

@dp.message(CommandStart())
async def start(message: Message):
    global OWNER_ID
    username = (message.from_user.username or "").lower()
    if username == OWNER_USERNAME and not OWNER_ID:
        OWNER_ID = message.chat.id
        log.info("Owner chat registered: %s", OWNER_ID)
    text = (
        "🟠 <b>SALE TRACKER</b>\n"
        "Твоя мини-CRM для клиентов, сделок и повторных касаний.\n\n"
        "Добавляй потенциальных клиентов, отслеживай этапы продаж, "
        "фиксируй доход и получай напоминания — всё в одном месте."
    )
    if not WEBAPP_URL:
        text += "\n\n⚙️ Mini App ещё не настроен. Добавь WEBAPP_URL в .env после публикации."
    await message.answer(text, reply_markup=app_keyboard(), parse_mode="HTML")

@dp.message(Command("id"))
async def get_id(message: Message):
    await message.answer(f"Твой Telegram ID: <code>{message.chat.id}</code>", parse_mode="HTML")

@dp.message(Command("help"))
async def help_cmd(message: Message):
    await message.answer(
        "Команды:\n/start — открыть SALE TRACKER\n/id — узнать свой Telegram ID\n"
        "Ошибки в приложении можно отправить через кнопку «Сообщить об ошибке»."
    )

@dp.message(lambda m: m.text == "Мой Telegram")
async def channel(message: Message):
    await message.answer("Канал BIG SELL: https://t.me/BIGSELL05")

async def reminder_worker(bot: Bot):
    while True:
        try:
            for item in await due_reminders():
                try:
                    await bot.send_message(
                        item["telegram_id"],
                        "⏰ <b>Напоминание о клиенте</b>\n"
                        f"Клиент: <b>{item['name']}</b>\n"
                        f"Заметка: {item.get('note') or 'Пора возобновить контакт'}",
                        parse_mode="HTML"
                    )
                    await mark_reminder_sent(item["id"])
                except Exception:
                    log.exception("Reminder delivery failed")
        except Exception:
            log.exception("Reminder worker failed")
        await asyncio.sleep(30)

async def main():
    if not BOT_TOKEN:
        raise RuntimeError("BOT_TOKEN is missing. Set it in .env")
    await init_db()
    bot = Bot(BOT_TOKEN)
    app = make_app(bot, lambda: OWNER_ID)
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "0.0.0.0", PORT)
    await site.start()
    log.info("Web/API server started on port %s", PORT)
    reminder_task = asyncio.create_task(reminder_worker(bot))
    try:
        await dp.start_polling(bot)
    finally:
        reminder_task.cancel()
        await runner.cleanup()
        await bot.session.close()

if __name__ == "__main__":
    asyncio.run(main())
