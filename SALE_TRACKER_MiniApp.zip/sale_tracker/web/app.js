const tg = window.Telegram?.WebApp;
if (tg) { tg.ready(); tg.expand(); tg.setHeaderColor?.("#080808"); tg.setBackgroundColor?.("#080808"); }
const $ = id => document.getElementById(id);
const labels = {new:"Новый",contacted:"Написал",negotiation:"Переговоры",paid:"Оплата",rejected:"Отказ"};
let clients=[], filter="all";
const headers = {"Content-Type":"application/json","X-Telegram-Init-Data":tg?.initData || ""};
async function api(path, opts={}) {
  const r=await fetch(path,{...opts,headers:{...headers,...opts.headers}});
  if(!r.ok){let t=await r.text();throw new Error(t||"Ошибка запроса");}
  return r.status===204?null:r.json();
}
function money(v){return new Intl.NumberFormat("ru-RU",{maximumFractionDigits:0}).format(Number(v||0))+" ₽";}
function toast(msg){$("toast").textContent=msg;$("toast").classList.add("show");setTimeout(()=>$("toast").classList.remove("show"),2600);}
function render(){
  const visible=clients.filter(c=>filter==="all"||c.status===filter);
  $("clientList").innerHTML=visible.length?visible.map(c=>`
    <article class="client" data-id="${c.id}">
      <div class="client-top"><div><div class="client-name">${esc(c.name)}</div><div class="client-contact">${esc(c.contact||c.source||"Контакт не указан")}</div></div><span class="pill ${c.status}">${labels[c.status]}</span></div>
      <div class="client-bottom"><span>${c.reminder_at&&!c.reminder_sent?"⏰ Есть напоминание":"Открыть карточку ↗"}</span><b>${money(c.commission)}</b></div>
    </article>`).join(""):`<div class="empty"><b>${filter==="all"?"Пока здесь пусто":"Нет клиентов на этом этапе"}</b>${filter==="all"?"Добавь первого потенциального клиента и начни вести свою воронку.":"Попробуй выбрать другой этап продаж."}</div>`;
  document.querySelectorAll(".client").forEach(el=>el.addEventListener("click",()=>openEdit(+el.dataset.id)));
}
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
async function refresh(){
  try{
    [clients]=await Promise.all([api("/api/clients")]);
    const s=await api("/api/stats");
    $("income").textContent=money(s.income);$("total").textContent=s.total_clients;
    $("week").textContent=money(s.week);$("month").textContent=money(s.month);render();
  }catch(e){$("clientList").innerHTML=`<div class="empty"><b>Не удалось загрузить данные</b>Открой Mini App из Telegram. Если проблема повторяется, отправь отчёт об ошибке.</div>`;console.error(e);}
}
function showModal(){ $("clientModal").classList.remove("hidden"); }
function hideModal(){ $("clientModal").classList.add("hidden"); }
function setVal(id,v){$(id).value=v??"";}
function openNew(){
  $("clientForm").reset();setVal("clientId","");$("modalTitle").textContent="Новый клиент";$("deleteBtn").classList.add("hidden");showModal();
}
function openEdit(id){
  const c=clients.find(x=>x.id===id);if(!c)return;
  $("clientForm").reset();setVal("clientId",c.id);$("modalTitle").textContent="Редактировать";
  ["name","contact","source","status","value","commission","note"].forEach(k=>setVal(k,c[k]));
  if(c.reminder_at){let d=new Date(c.reminder_at);setVal("reminder",new Date(d.getTime()-d.getTimezoneOffset()*60000).toISOString().slice(0,16));}
  $("deleteBtn").classList.remove("hidden");showModal();
}
$("addBtn").onclick=openNew;
document.querySelectorAll("[data-close]").forEach(b=>b.onclick=hideModal);
$("clientModal").addEventListener("click",e=>{if(e.target.id==="clientModal")hideModal();});
$("filters").addEventListener("click",e=>{let b=e.target.closest("[data-filter]");if(!b)return;filter=b.dataset.filter;document.querySelectorAll(".filter").forEach(x=>x.classList.toggle("active",x===b));render();});
$("clientForm").addEventListener("submit",async e=>{
 e.preventDefault();
 const id=$("clientId").value, reminder=$("reminder").value;
 const payload={name:$("name").value,contact:$("contact").value,source:$("source").value,status:$("status").value,value:$("value").value,commission:$("commission").value,note:$("note").value,reminder_at:reminder?new Date(reminder).toISOString():null};
 try{await api(id?`/api/clients/${id}`:"/api/clients",{method:id?"PATCH":"POST",body:JSON.stringify(payload)});hideModal();toast("Клиент сохранён");await refresh();}
 catch(err){toast("Не удалось сохранить: "+err.message);}
});
$("deleteBtn").onclick=async()=>{const id=$("clientId").value;if(!id||!confirm("Удалить клиента?"))return;try{await api(`/api/clients/${id}`,{method:"DELETE"});hideModal();toast("Клиент удалён");await refresh();}catch(e){toast("Ошибка удаления");}};
$("errorBtn").onclick=async()=>{const message=prompt("Кратко опиши, что произошло:");if(message===null)return;try{await api("/api/report-error",{method:"POST",body:JSON.stringify({message})});toast("Отчёт отправлен. Спасибо!");}catch(e){toast("Не удалось отправить отчёт");}};
refresh();
