import aiosqlite, os
from pathlib import Path
from datetime import datetime, timezone

DB_PATH = os.getenv("DB_PATH", "sale_tracker.db")
Path(DB_PATH).parent.mkdir(parents=True, exist_ok=True)

async def init_db():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            telegram_id INTEGER PRIMARY KEY, username TEXT, first_name TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS clients (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            telegram_id INTEGER NOT NULL,
            name TEXT NOT NULL, contact TEXT DEFAULT '', source TEXT DEFAULT '',
            status TEXT NOT NULL DEFAULT 'new', value REAL DEFAULT 0,
            commission REAL DEFAULT 0, note TEXT DEFAULT '',
            reminder_at TEXT DEFAULT NULL, reminder_sent INTEGER DEFAULT 0,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP, updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE INDEX IF NOT EXISTS idx_clients_user ON clients(telegram_id);
        CREATE INDEX IF NOT EXISTS idx_reminders ON clients(reminder_at, reminder_sent);
        """)
        await db.commit()

async def due_reminders():
    now = datetime.now(timezone.utc).isoformat()
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute(
            "SELECT id, telegram_id, name, note FROM clients "
            "WHERE reminder_at IS NOT NULL AND reminder_at <= ? AND reminder_sent=0", (now,)
        )
        return [dict(r) for r in await cur.fetchall()]

async def mark_reminder_sent(client_id):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE clients SET reminder_sent=1 WHERE id=?", (client_id,))
        await db.commit()
