import hashlib, hmac, json, logging, os, time
from urllib.parse import parse_qsl
from datetime import datetime, timezone
import aiosqlite
from aiohttp import web
from database import DB_PATH

log = logging.getLogger("sale_tracker.api")
BOT_TOKEN = os.getenv("BOT_TOKEN", "")
OWNER_USERNAME = os.getenv("OWNER_USERNAME", "ERE321").lstrip("@").lower()
STATUSES = {"new", "contacted", "negotiation", "paid", "rejected"}

def validate_init_data(init_data: str):
    if not init_data or not BOT_TOKEN:
        return None
    try:
        data = dict(parse_qsl(init_data, keep_blank_values=True))
        received_hash = data.pop("hash", None)
        if not received_hash:
            return None
        check_string = "\n".join(f"{k}={v}" for k, v in sorted(data.items()))
        secret = hmac.new(b"WebAppData", BOT_TOKEN.encode(), hashlib.sha256).digest()
        calculated = hmac.new(secret, check_string.encode(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(calculated, received_hash):
            return None
        auth_date = int(data.get("auth_date", "0"))
        if abs(time.time() - auth_date) > 86400:
            return None
        user = json.loads(data.get("user", "{}"))
        return user if user.get("id") else None
    except Exception:
        return None

@web.middleware
async def auth_middleware(request, handler):
    if request.path in ("/", "/index.html", "/health", "/app.js", "/style.css", "/logo.png"):
        return await handler(request)
    if request.path.startswith("/api/"):
        user = validate_init_data(request.headers.get("X-Telegram-Init-Data", ""))
        if not user:
            return web.json_response({"error": "Unauthorized. Open the app inside Telegram."}, status=401)
        request["tg_user"] = user
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute(
                "INSERT INTO users(telegram_id, username, first_name) VALUES(?,?,?) "
                "ON CONFLICT(telegram_id) DO UPDATE SET username=excluded.username, first_name=excluded.first_name",
                (user["id"], user.get("username", ""), user.get("first_name", ""))
            )
            await db.commit()
    return await handler(request)

async def json_body(request):
    try:
        return await request.json()
    except Exception:
        raise web.HTTPBadRequest(text="Invalid JSON")

def clean_text(value, limit=500):
    return str(value or "").strip()[:limit]

async def list_clients(request):
    uid = request["tg_user"]["id"]
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute("SELECT * FROM clients WHERE telegram_id=? ORDER BY created_at DESC", (uid,))
        return web.json_response([dict(r) for r in await cur.fetchall()])

async def create_client(request):
    uid = request["tg_user"]["id"]
    data = await json_body(request)
    name = clean_text(data.get("name"), 100)
    if not name:
        raise web.HTTPBadRequest(text="Укажи имя клиента")
    status = data.get("status", "new")
    if status not in STATUSES: status = "new"
    try:
        value, commission = max(0, float(data.get("value") or 0)), max(0, float(data.get("commission") or 0))
    except (ValueError, TypeError):
        raise web.HTTPBadRequest(text="Сумма должна быть числом")
    reminder = clean_text(data.get("reminder_at"), 40) or None
    if reminder:
        try:
            parsed = datetime.fromisoformat(reminder.replace("Z", "+00:00"))
            if parsed.tzinfo is None: parsed = parsed.replace(tzinfo=timezone.utc)
            reminder = parsed.astimezone(timezone.utc).isoformat()
        except ValueError:
            raise web.HTTPBadRequest(text="Некорректная дата напоминания")
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "INSERT INTO clients(telegram_id,name,contact,source,status,value,commission,note,reminder_at) "
            "VALUES(?,?,?,?,?,?,?,?,?)",
            (uid, name, clean_text(data.get("contact"),150), clean_text(data.get("source"),100),
             status, value, commission, clean_text(data.get("note"),1000), reminder)
        )
        await db.commit()
        return web.json_response({"id": cur.lastrowid}, status=201)

async def update_client(request):
    uid, cid = request["tg_user"]["id"], int(request.match_info["client_id"])
    data = await json_body(request)
    fields = {}
    for key, limit in (("name",100),("contact",150),("source",100),("note",1000)):
        if key in data: fields[key] = clean_text(data[key], limit)
    if "status" in data:
        if data["status"] not in STATUSES: raise web.HTTPBadRequest(text="Неизвестный статус")
        fields["status"] = data["status"]
    for key in ("value","commission"):
        if key in data:
            try: fields[key] = max(0, float(data[key] or 0))
            except (ValueError,TypeError): raise web.HTTPBadRequest(text="Сумма должна быть числом")
    if "reminder_at" in data:
        val = clean_text(data["reminder_at"],40)
        if val:
            try:
                dt = datetime.fromisoformat(val.replace("Z","+00:00"))
                if dt.tzinfo is None: dt=dt.replace(tzinfo=timezone.utc)
                fields["reminder_at"] = dt.astimezone(timezone.utc).isoformat()
                fields["reminder_sent"] = 0
            except ValueError: raise web.HTTPBadRequest(text="Некорректная дата")
        else:
            fields["reminder_at"] = None
            fields["reminder_sent"] = 0
    if not fields: return web.json_response({"ok":True})
    fields["updated_at"] = datetime.now(timezone.utc).isoformat()
    sql = ", ".join(f"{k}=?" for k in fields)
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(f"UPDATE clients SET {sql} WHERE id=? AND telegram_id=?",
                               (*fields.values(), cid, uid))
        await db.commit()
        if cur.rowcount == 0: raise web.HTTPNotFound(text="Клиент не найден")
    return web.json_response({"ok":True})

async def delete_client(request):
    uid, cid = request["tg_user"]["id"], int(request.match_info["client_id"])
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("DELETE FROM clients WHERE id=? AND telegram_id=?", (cid,uid))
        await db.commit()
        if cur.rowcount == 0: raise web.HTTPNotFound(text="Клиент не найден")
    return web.json_response({"ok":True})

async def stats(request):
    uid = request["tg_user"]["id"]
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute("SELECT status, COUNT(*) count FROM clients WHERE telegram_id=? GROUP BY status",(uid,))
        counts = {r["status"]:r["count"] for r in await cur.fetchall()}
        cur = await db.execute(
            "SELECT COALESCE(SUM(commission),0) total, COUNT(*) deals FROM clients "
            "WHERE telegram_id=? AND status='paid'",(uid,))
        alltime = dict(await cur.fetchone())
        cur = await db.execute(
            "SELECT COALESCE(SUM(commission),0) total FROM clients WHERE telegram_id=? "
            "AND status='paid' AND created_at >= datetime('now','-7 days')",(uid,))
        week = (await cur.fetchone())[0]
        cur = await db.execute(
            "SELECT COALESCE(SUM(commission),0) total FROM clients WHERE telegram_id=? "
            "AND status='paid' AND created_at >= datetime('now','start of month')",(uid,))
        month = (await cur.fetchone())[0]
    return web.json_response({"counts":counts,"income":alltime["total"],"deals":alltime["deals"],
                              "week":week,"month":month,"total_clients":sum(counts.values())})

async def report_error(request):
    data = await json_body(request)
    uid = request["tg_user"]["id"]
    detail = clean_text(data.get("message"),1200)
    log.error("User error report | user=%s | %s", uid, detail)
    bot = request.app["bot"]
    owner_id = request.app["owner_id"]()
    if owner_id:
        try:
            await bot.send_message(owner_id,
                f"⚠️ <b>SALE TRACKER — сообщение об ошибке</b>\n"
                f"Пользователь ID: <code>{uid}</code>\n"
                f"Описание: {detail or 'Без описания'}",
                parse_mode="HTML")
        except Exception:
            log.exception("Could not send error report to owner")
    return web.json_response({"ok":True})

async def index(request):
    return web.FileResponse("web/index.html")

def make_app(bot, owner_id):
    app = web.Application(middlewares=[auth_middleware], client_max_size=1024*1024)
    app["bot"], app["owner_id"] = bot, owner_id
    app.router.add_get("/", index)
    app.router.add_get("/health", lambda r: web.json_response({"ok":True}))
    app.router.add_get("/app.js", lambda r: web.FileResponse("web/app.js"))
    app.router.add_get("/style.css", lambda r: web.FileResponse("web/style.css"))
    app.router.add_get("/logo.png", lambda r: web.FileResponse("web/logo.png"))
    app.router.add_get("/api/clients", list_clients)
    app.router.add_post("/api/clients", create_client)
    app.router.add_patch("/api/clients/{client_id}", update_client)
    app.router.add_delete("/api/clients/{client_id}", delete_client)
    app.router.add_get("/api/stats", stats)
    app.router.add_post("/api/report-error", report_error)
    return app
